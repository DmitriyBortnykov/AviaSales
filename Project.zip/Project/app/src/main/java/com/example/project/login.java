package com.example.project;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;


import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rengwuxian.materialedittext.MaterialEditText;

public class login extends AppCompatActivity {


    FirebaseAuth auth;
    FirebaseDatabase db;
    DatabaseReference users;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        users = db.getReference("Users");
    }
    public void startMain(View v) {
        Intent login = new Intent(this, com.example.project.MainActivity.class);
        startActivity(login);
    }

    public void startProfile(View v) {
        Intent prof = new Intent(this, com.example.project.profile.class);
        startActivity(prof);
    }
    public void startAutorization(View v) {
        //Перевірка даних,розблокування бронювання
        //Перевірка даних,розблокування бронювання
        //Перевірка даних,розблокування бронювання
        Intent auto = new Intent(this, com.example.project.authorization.class);
        startAuto();
        startActivity(auto);//Перевірка даних,розблокування бронювання
    }

    public void startAuto() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Error");
        dialog.setMessage("Error");
        LayoutInflater inflater = LayoutInflater.from(this);
        View authorization = inflater.inflate(R.layout.authorization, null);
        final  MaterialEditText phone = authorization.findViewById(R.id.Phone);
        MaterialEditText login = authorization.findViewById(R.id.logining);
        MaterialEditText Name = authorization.findViewById(R.id.Name);
        MaterialEditText Surname = authorization.findViewById(R.id.Surname);
        MaterialEditText pass = authorization.findViewById(R.id.quest2);
        dialog.setPositiveButton("add",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                if(TextUtils.isEmpty(phone.getText().toString())||TextUtils.isEmpty(login.getText().toString())||TextUtils.isEmpty(Name.getText().toString())||TextUtils.isEmpty(Surname.getText().toString())||TextUtils.isEmpty(pass.getText().toString())){

                    return;
                }
                auth.createUserWithEmailAndPassword(login.getText().toString(), pass.getText().toString())
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                User user = new User();
                                user.setName(Name.getText().toString());
                                user.setSurname(Surname.getText().toString());
                                user.setPhone(phone.getText().toString());
                                user.setLogin(login.getText().toString());
                                user.setPass(pass.getText().toString());
                                users.child(user.getLogin())
                                        .setValue(user)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {

                                            }
                                        });
                            }
                        });

            }



        });
        dialog.show();
    }



    }