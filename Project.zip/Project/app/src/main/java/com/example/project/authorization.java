package com.example.project;



import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;


import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.snackbar.SnackbarContentLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rengwuxian.materialedittext.MaterialEditText;
class User {
    private String Name,Surname,phone,login,pass;
    public User(){}
    public User(String Name,String Surname,String phone,String login,String pass )   {
        this.Name= Name;
        this.Surname= Surname;
        this.phone  = phone;
        this.login= login;
        this.pass= pass;

    }
    public String getName(){
        return Name;
    }
    public void setName(String Name){
        this.Name= Name;
    }
    public String getSurname(){
        return Surname;
    }
    public void setSurname(String Surname){
        this.Surname= Surname;
    }
    public String getPhone(){
        return phone;
    }
    public void setPhone(String phone)    {

        this.phone= phone;
    }
    public String getLogin(){
        return login;
    }
    public void setLogin(String login){
        this.login=login;
    }
    public String getPass(){
        return pass;
    }
    public void setPass(String pass){
        this.pass=pass;
    }



}

public class authorization extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.authorization);

    }
    public void startMain(View v) {
        Intent login = new Intent(this, com.example.project.MainActivity.class);
        startActivity(login);
    }
    public void startLogin(View v) {
        Intent login = new Intent(this, com.example.project.login.class);
        startActivity(login);
    }
    public void startProfile(View v) {
        Intent prof = new Intent(this, com.example.project.profile.class);
        startActivity(prof);
    }




}